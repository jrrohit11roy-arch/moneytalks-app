Set-Location $PSScriptRoot
& "C:\Program Files\nodejs\node.exe" server.js
